﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static c969v2.Inventory;

namespace c969v2
{
    public partial class AddPart : Form
    {
        private Inventory inventory;

        public AddPart(Inventory inventory)
        {
            InitializeComponent();
            radioButton1.CheckedChanged += new EventHandler(RadioButton_CheckedChanged);
            radioButton2.CheckedChanged += new EventHandler(RadioButton_CheckedChanged);
            this.inventory = inventory;
            textBox1.ReadOnly = true;

        }

        private void AddPart_Load(object sender, EventArgs e)
        {
            textBox1.Text = PartIDGenerator.GetNextID().ToString();


        }
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label7.Text = "Machine ID";
            }
            else if (radioButton2.Checked)
            {
                label7.Text = "Company Name";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                int partID = int.Parse(textBox1.Text);
                string partName = textBox2.Text;
                int inStock = int.Parse(textBox7.Text);
                decimal partPrice = decimal.Parse(textBox3.Text);
                int min = int.Parse(textBox4.Text);
                int max = int.Parse(textBox5.Text);
                string machineCompany = textBox6.Text;
                Part newPart;
                if (inStock < min || inStock > max)
                {
                    MessageBox.Show("Inventory must be between Min and Max values.");
                    return;
                }
                if (radioButton1.Checked)
                {
                    int machineID = int.Parse(textBox6.Text);
                    newPart = new InHouse
                    {
                        PartID = partID,
                        Name = partName,
                        Price = partPrice,
                        InStock = inStock,
                        Min = min,
                        Max = max,
                        MachineID = machineID
                    };
                }
                else
                {
                    string companyName = textBox6.Text;
                    newPart = new Outsourced
                    {
                        PartID = partID,
                        Name = partName,
                        Price = partPrice,
                        InStock = inStock,
                        Min = min,
                        Max = max,
                        CompanyName = companyName
                    };
                }
                inventory.AddPart(newPart);
                this.Close();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool ValidateInput()
        {
            try
            {
                ValidateTextBox(textBox2, "part name");
                ValidateTextBox(textBox3, "price", isDecimal: true);
                ValidateTextBox(textBox7, "inventory stock", isInteger: true);
                ValidateTextBox(textBox4, "minimum inventory", isInteger: true);
                ValidateTextBox(textBox5, "maximum inventory", isInteger: true);

                int inStock = int.Parse(textBox7.Text);
                int min = int.Parse(textBox4.Text);
                int max = int.Parse(textBox5.Text);

                if (!ValidateMinMaxInventory(min, max, inStock))
                {
                    return false;
                }

                if (radioButton1.Checked && !int.TryParse(textBox6.Text, out _))
                {
                    MessageBox.Show("Machine ID must be an integer.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (radioButton2.Checked && string.IsNullOrWhiteSpace(textBox6.Text))
                {
                    MessageBox.Show("Company Name must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        private bool ValidateMinMaxInventory(int min, int max, int inStock)
        {
            if (min > max)
            {
                MessageBox.Show("Min cannot be larger than Max.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (inStock < min || inStock > max)
            {
                MessageBox.Show("Inventory must be between Min and Max values.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        private void ValidateTextBox(TextBox textBox, string fieldName, bool isInteger = false, bool isDecimal = false)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                throw new Exception($"Please fill out the {fieldName}.");
            }

            if (isInteger && !int.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid integer for {fieldName}.");
            }

            if (isDecimal && !decimal.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid number for {fieldName}.");
            }
        }

    }
}
