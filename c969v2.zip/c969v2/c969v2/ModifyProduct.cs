﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace c969v2
{
    public partial class ModifyProduct : Form
    {
        private Inventory inventory;
        private BindingList<Part> associatedParts;
        private Product existingProduct;

        public ModifyProduct(Inventory inventory, Product product)
        {
            InitializeComponent();
            this.inventory = inventory;
            this.existingProduct = product;
            dataGridView1.DataSource = inventory.AllParts;
            associatedParts = new BindingList<Part>(product.AssociatedParts.ToList());
            dataGridView2.DataSource = associatedParts;
            textBox2.ReadOnly = true;
            LoadProductDetails();
        }

        private void LoadProductDetails()
        {
            if (existingProduct == null)
                return;

            textBox2.Text = existingProduct.ProductID.ToString();
            textBox3.Text = existingProduct.Name;
            textBox4.Text = existingProduct.InStock.ToString();
            textBox5.Text = existingProduct.Price.ToString();
            textBox7.Text = existingProduct.Min.ToString();
            textBox6.Text = existingProduct.Max.ToString();
        }

        private void BtnDeletePart_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow != null)
            {
                Part selectedPart = (Part)dataGridView2.CurrentRow.DataBoundItem;
                associatedParts.Remove(selectedPart);
            }
        }

        private void CancelModifyPart(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnAddPart_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is Part selectedPart)
            {
                if (!associatedParts.Contains(selectedPart))
                {
                    associatedParts.Add(selectedPart);
                }
            }
        }

        private bool ValidateMinMaxInventory(int min, int max, int inStock)
        {
            if (min > max)
            {
                MessageBox.Show("Min cannot be larger than Max.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (inStock < min || inStock > max)
            {
                MessageBox.Show("Inventory must be between Min and Max values.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                string name = textBox3.Text;
                decimal price = decimal.Parse(textBox5.Text);
                int inStock = int.Parse(textBox4.Text);
                int min = int.Parse(textBox7.Text);
                int max = int.Parse(textBox6.Text);

                if (inStock < min || inStock > max)
                {
                    MessageBox.Show("Inventory must be between Min and Max values.");
                    return;
                }

                existingProduct.Name = name;
                existingProduct.Price = price;
                existingProduct.InStock = inStock;
                existingProduct.Min = min;
                existingProduct.Max = max;

                existingProduct.AssociatedParts.Clear();
                foreach (var part in associatedParts)
                {
                    existingProduct.AddAssociatedPart(part);
                }

                var productIndex = inventory.Products.IndexOf(inventory.Products.First(p => p.ProductID == existingProduct.ProductID));
                if (productIndex >= 0)
                {
                    inventory.Products[productIndex] = existingProduct;
                }

                this.Close();
            }
        }

        private bool ValidateInput()
        {
            try
            {
                ValidateTextBox(textBox3, "product name");
                ValidateTextBox(textBox5, "price", isDecimal: true);
                ValidateTextBox(textBox4, "inventory stock", isInteger: true);
                ValidateTextBox(textBox7, "minimum inventory", isInteger: true);
                ValidateTextBox(textBox6, "maximum inventory", isInteger: true);

                int inStock = int.Parse(textBox4.Text);
                int min = int.Parse(textBox7.Text);
                int max = int.Parse(textBox6.Text);

                if (!ValidateMinMaxInventory(min, max, inStock))
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void ValidateTextBox(TextBox textBox, string fieldName, bool isInteger = false, bool isDecimal = false)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                throw new Exception($"Please fill out the {fieldName}.");
            }

            if (isInteger && !int.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid integer for {fieldName}.");
            }

            if (isDecimal && !decimal.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid number for {fieldName}.");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = textBox1.Text.ToLower();
            var filteredParts = inventory.SearchParts(searchTerm);

            if (filteredParts.Count == 0)
            {
                MessageBox.Show("No parts found matching the search term.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                dataGridView1.DataSource = new BindingList<Part>(filteredParts);
            }
        }
    }
}
