﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c969v2
{
    public partial class ModifyPart : Form
    {
        private Inventory inventory;
        private Part existingPart;

        public ModifyPart(Inventory inventory, Part part)
        {
            InitializeComponent();
            radioButton1.CheckedChanged += new EventHandler(RadioButton_CheckedChanged);
            radioButton2.CheckedChanged += new EventHandler(RadioButton_CheckedChanged);
            this.inventory = inventory;
            this.existingPart = part;
            textBox1.ReadOnly = true;
            LoadPartDetails();
        }

        private void LoadPartDetails()
        {
            if (existingPart == null)
                return;

            textBox1.Text = existingPart.PartID.ToString();
            textBox2.Text = existingPart.Name;
            textBox3.Text = existingPart.InStock.ToString();
            textBox4.Text = existingPart.Price.ToString();
            textBox5.Text = existingPart.Min.ToString();
            textBox6.Text = existingPart.Max.ToString();

            if (existingPart is InHouse inHousePart)
            {
                radioButton1.Checked = true;
                label8.Text = "Machine ID";
                textBox8.Text = inHousePart.MachineID.ToString();
            }
            else if (existingPart is Outsourced outsourcedPart)
            {
                radioButton2.Checked = true;
                label8.Text = "Company Name";
                textBox8.Text = outsourcedPart.CompanyName;
            }
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label8.Text = "Machine ID";
            }
            else if (radioButton2.Checked)
            {
                label8.Text = "Company Name";
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (existingPart == null)
            {
                MessageBox.Show("No part selected for modification.");
                return;
            }

            if (ValidateInput())
            {
                int partID = int.Parse(textBox1.Text);
                string partName = textBox2.Text;
                int inStock = int.Parse(textBox3.Text);
                decimal partPrice = decimal.Parse(textBox4.Text);
                int min = int.Parse(textBox5.Text);
                int max = int.Parse(textBox6.Text);
                Part modifiedPart;

                if (radioButton1.Checked)
                {
                    if (!int.TryParse(textBox8.Text, out int machineID))
                    {
                        MessageBox.Show("Machine ID must be an integer.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    modifiedPart = new InHouse
                    {
                        PartID = partID,
                        Name = partName,
                        Price = partPrice,
                        InStock = inStock,
                        Min = min,
                        Max = max,
                        MachineID = machineID
                    };
                }
                else
                {
                    string companyName = textBox8.Text;
                    modifiedPart = new Outsourced
                    {
                        PartID = partID,
                        Name = partName,
                        Price = partPrice,
                        InStock = inStock,
                        Min = min,
                        Max = max,
                        CompanyName = companyName
                    };
                }

                inventory.UpdatePart(partID, modifiedPart);
                this.Close();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool ValidateInput()
        {
            try
            {
                ValidateTextBox(textBox2, "part name");
                ValidateTextBox(textBox4, "price", isDecimal: true);
                ValidateTextBox(textBox3, "inventory stock", isInteger: true);
                ValidateTextBox(textBox5, "minimum inventory", isInteger: true);
                ValidateTextBox(textBox6, "maximum inventory", isInteger: true);

                int inStock = int.Parse(textBox3.Text);
                int min = int.Parse(textBox5.Text);
                int max = int.Parse(textBox6.Text);

                if (!ValidateMinMaxInventory(min, max, inStock))
                {
                    return false;
                }

                if (radioButton1.Checked && !int.TryParse(textBox8.Text, out _))
                {
                    MessageBox.Show("Machine ID must be an integer.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (radioButton2.Checked && string.IsNullOrWhiteSpace(textBox8.Text))
                {
                    MessageBox.Show("Company Name must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private bool ValidateMinMaxInventory(int min, int max, int inStock)
        {
            if (min > max)
            {
                MessageBox.Show("Min cannot be larger than Max.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (inStock < min || inStock > max)
            {
                MessageBox.Show("Inventory must be between Min and Max values.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void ValidateTextBox(TextBox textBox, string fieldName, bool isInteger = false, bool isDecimal = false)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                throw new Exception($"Please fill out the {fieldName}.");
            }

            if (isInteger && !int.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid integer for {fieldName}.");
            }

            if (isDecimal && !decimal.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid number for {fieldName}.");
            }
        }
    }
}
