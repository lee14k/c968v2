﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static c969v2.Inventory;

namespace c969v2
{
    public partial class AddProduct : Form
    {

        private Inventory inventory;
        private BindingList<Part> associatedParts = new BindingList<Part>();
        public AddProduct(Inventory inventory)
        {
            InitializeComponent();
            this.inventory = inventory;

            dataGridView1.DataSource = inventory.AllParts;
            dataGridView2.DataSource = associatedParts;
            textBox2.ReadOnly = true;
            textBox2.Text = ProductIDGenerator.GetNextID().ToString();

        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns["PartID"].HeaderText = "Part ID";
            dataGridView1.Columns["Name"].HeaderText = "Name";
            dataGridView1.Columns["InStock"].HeaderText = "Inventory";
            dataGridView1.Columns["Price"].HeaderText = "Price";
            dataGridView1.Columns["Min"].HeaderText = "Min";
            dataGridView1.Columns["Max"].HeaderText = "Max";

            dataGridView2.Columns["PartID"].HeaderText = "Part ID";
            dataGridView2.Columns["Name"].HeaderText = "Name";
            dataGridView2.Columns["InStock"].HeaderText = "Inventory";
            dataGridView2.Columns["Price"].HeaderText = "Price";
            dataGridView2.Columns["Min"].HeaderText = "Min";
            dataGridView2.Columns["Max"].HeaderText = "Max";
        }
        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                int productID = int.Parse(textBox2.Text);
                string name = textBox3.Text;
                decimal price = decimal.Parse(textBox5.Text);
                int inStock = int.Parse(textBox4.Text);
                int min = int.Parse(textBox6.Text);
                int max = int.Parse(textBox7.Text);
                if (inStock < min || inStock > max)
                {
                    MessageBox.Show("Inventory must be between Min and Max values.");
                    return;
                }
                Product newProduct = new Product
                {
                    ProductID = productID,
                    Name = name,
                    Price = price,
                    InStock = inStock,
                    Min = min,
                    Max = max,
                    AssociatedParts = associatedParts
                };

                inventory.AddProduct(newProduct);
                this.Close();
            }

        }
        private void BtnDeletePart_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow != null)
            {
                Part selectedPart = (Part)dataGridView2.CurrentRow.DataBoundItem;
                associatedParts.Remove(selectedPart);
            }
        }

        private void BtnAddPart_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is Part selectedPart)
            {
                if (!associatedParts.Contains(selectedPart))
                {
                    associatedParts.Add(selectedPart);
                }
            }
        }


        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool ValidateInput()
        {
            try
            {
                ValidateTextBox(textBox3, "product name");
                ValidateTextBox(textBox5, "price", isDecimal: true);
                ValidateTextBox(textBox4, "inventory stock", isInteger: true);
                ValidateTextBox(textBox6, "minimum inventory", isInteger: true);
                ValidateTextBox(textBox7, "maximum inventory", isInteger: true);

                int inStock = int.Parse(textBox4.Text);
                int min = int.Parse(textBox7.Text);
                int max = int.Parse(textBox6.Text);

                if (!ValidateMinMaxInventory(min, max, inStock))
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = textBox1.Text.ToLower();
            var filteredParts = inventory.SearchParts(searchTerm);

            if (filteredParts.Count == 0)
            {
                MessageBox.Show("No parts found matching the search term.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                dataGridView1.DataSource = new BindingList<Part>(filteredParts);
            }
        }

        private bool ValidateMinMaxInventory(int min, int max, int inStock)
        {
            if (min > max)
            {
                MessageBox.Show("Min cannot be larger than Max.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (inStock < min || inStock > max)
            {
                MessageBox.Show("Inventory must be between Min and Max values.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        private void ValidateTextBox(TextBox textBox, string fieldName, bool isInteger = false, bool isDecimal = false)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                throw new Exception($"Please fill out the {fieldName}.");
            }

            if (isInteger && !int.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid integer for {fieldName}.");
            }

            if (isDecimal && !decimal.TryParse(textBox.Text, out _))
            {
                throw new Exception($"Please enter a valid number for {fieldName}.");
            }
        }
    }


}
