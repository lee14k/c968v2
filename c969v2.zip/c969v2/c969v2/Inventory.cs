﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace c969v2
{
    public class Inventory
    {
        public BindingList<Product> Products { get; set; } = new BindingList<Product>();
        public BindingList<Part> AllParts { get; set; } = new BindingList<Part>();

        public void AddProduct(Product product)
        {
            Products.Add(product);
        }

        public bool RemoveProduct(int productID)
        {
            Product productToRemove = Products.FirstOrDefault(p => p.ProductID == productID);
            if (productToRemove != null)
            {
                Products.Remove(productToRemove);
                return true;
            }
            return false;
        }

        public Product LookupProduct(int productID)
        {
            return Products.FirstOrDefault(p => p.ProductID == productID);
        }

        public List<Product> LookupProduct(string searchTerm)
        {
            return Products.Where(p => p.Name.ToLower().Contains(searchTerm.ToLower())).ToList();
        }

        public List<Product> SearchProducts(string searchTerm)
        {
            int searchId;
            bool isNumeric = int.TryParse(searchTerm, out searchId);

            return Products.Where(p =>
                p.Name.ToLower().Contains(searchTerm.ToLower()) ||
                (isNumeric && p.ProductID == searchId)
            ).ToList();
        }

        public void UpdateProduct(int productID, Product newProduct)
        {
            Product productToUpdate = Products.FirstOrDefault(p => p.ProductID == productID);
            if (productToUpdate != null)
            {
                int index = Products.IndexOf(productToUpdate);
                Products[index] = newProduct;
            }
        }

        public void AddPart(Part part)
        {
            AllParts.Add(part);
        }

        public bool RemovePart(int partID)
        {
            Part partToRemove = AllParts.FirstOrDefault(p => p.PartID == partID);
            if (partToRemove != null)
            {
                AllParts.Remove(partToRemove);
                return true;
            }
            return false;
        }

        public bool DeletePart(Part part)
        {
            if (AllParts.Contains(part))
            {
                AllParts.Remove(part);
                return true;
            }
            return false;
        }

        public List<Part> LookupPart(string searchTerm)
        {
            return AllParts.Where(p => p.Name.ToLower().Contains(searchTerm.ToLower())).ToList();
        }

        public Part LookupPart(int partID)
        {
            return AllParts.FirstOrDefault(p => p.PartID == partID);
        }

        public List<Part> SearchParts(string searchTerm)
        {
            int searchId;
            bool isNumeric = int.TryParse(searchTerm, out searchId);

            return AllParts.Where(p =>
                p.Name.ToLower().Contains(searchTerm.ToLower()) ||
                (isNumeric && p.PartID == searchId)
            ).ToList();
        }

        public void UpdatePart(int partID, Part newPart)
        {
            Part partToUpdate = AllParts.FirstOrDefault(p => p.PartID == partID);
            if (partToUpdate != null)
            {
                int index = AllParts.IndexOf(partToUpdate);
                AllParts[index] = newPart;
            }
        }

        public bool IsPartAssociatedWithAnyProduct(int partID)
        {
            foreach (var product in Products)
            {
                if (product.AssociatedParts.Any(p => p.PartID == partID))
                {
                    return true;
                }
            }
            return false;
        }

        public bool HasAssociatedParts(int productID)
        {
            Product product = Products.FirstOrDefault(p => p.ProductID == productID);
            return product != null && product.AssociatedParts.Any();
        }

        public static class PartIDGenerator
        {
            private static int currentID = 3;

            public static int GetNextID()
            {
                return currentID++;
            }
        }

        public static class ProductIDGenerator
        {
            private static int currentID = 2;

            public static int GetNextID()
            {
                return currentID++;
            }
        }
    }
}
