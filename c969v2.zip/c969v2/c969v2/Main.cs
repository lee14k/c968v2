﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c969v2
{
    public partial class Main : Form
    {
        private Inventory inventory;
        public Main()
        {
            InitializeComponent();
            inventory = new Inventory();
            InitializeInventory();
            dataGridViewProducts.DataSource = inventory.Products;
            dataGridViewParts.DataSource = inventory.AllParts;

        }
        private void InitializeInventory()
        {

            inventory.AddProduct(new Product
            {
                ProductID = 1,
                Name = "Bicycle",
                InStock = 10,
                Price = 299.99M,
                Min = 1,
                Max = 15
            });
            inventory.AddPart(new InHouse
            {
                PartID = 1,
                Name = "Gear",
                Price = 10.99M,
                InStock = 15,
                Min = 1,
                Max = 20,
                MachineID = 1001
            });

            inventory.AddPart(new Outsourced
            {
                PartID = 2,
                Name = "Bolt",
                Price = 0.99M,
                InStock = 100,
                Min = 10,
                Max = 200,
                CompanyName = "BoltSupply",
            });

        }
        private void button2_click(object sender, EventArgs e)
        {
            AddPart addPart = new AddPart(inventory);
            addPart.Show();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridViewParts.SelectedRows.Count > 0)
            {
                int selectedPartID = int.Parse(dataGridViewParts.SelectedRows[0].Cells[0].Value.ToString());

                Part selectedPart = inventory.LookupPart(selectedPartID);

                if (selectedPart != null)
                {
                    ModifyPart modifyPartForm = new ModifyPart(inventory, selectedPart);
                    modifyPartForm.ShowDialog();
                    dataGridViewParts.DataSource = inventory.AllParts;
                }
                else
                {
                    MessageBox.Show("Part not found.");
                }
            }
            else
            {
                MessageBox.Show("Please select a part to modify.");
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            AddProduct addProductForm = new AddProduct(inventory);
            addProductForm.ShowDialog();
        }

        private void BtnSearchPart_Click(object sender, EventArgs e)
        {
            string searchTerm = textBox1.Text.ToLower();
            var filteredParts = inventory.SearchParts(searchTerm);
            dataGridViewParts.DataSource = new BindingList<Part>(filteredParts);
            if (filteredParts.Count == 0)
            {
                MessageBox.Show("No parts found matching the search term.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnSearchProduct_Click(object sender, EventArgs e)
        {
            string searchTerm = textBox2.Text.ToLower();
            var filteredProducts = inventory.SearchProducts(searchTerm);
            dataGridViewProducts.DataSource = new BindingList<Product>(filteredProducts);
            if (filteredProducts.Count == 0)
            {
                MessageBox.Show("No products found matching the search term.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeletePart(object sender, EventArgs e)
        {
            if (dataGridViewParts.SelectedRows.Count > 0)
            {
                int selectedPartID = int.Parse(dataGridViewParts.SelectedRows[0].Cells[0].Value.ToString());

                if (inventory.IsPartAssociatedWithAnyProduct(selectedPartID))
                {
                    MessageBox.Show("This part cannot be deleted because it is associated with a product.");
                }
                else
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this part?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (result == DialogResult.Yes)
                    {
                        inventory.RemovePart(selectedPartID);
                        dataGridViewParts.DataSource = inventory.AllParts;
                    }

                }
            }
            else
            {
                MessageBox.Show("Please select a part to delete.");
            }
        }
        private void DeleteProduct_Click(object sender, EventArgs e)
        {
            if (dataGridViewProducts.SelectedRows.Count > 0)
            {
                int selectedProductID = int.Parse(dataGridViewProducts.SelectedRows[0].Cells[0].Value.ToString());
                if (inventory.HasAssociatedParts(selectedProductID))
                {
                    MessageBox.Show("This product cannot be deleted because it has associated parts.");
                }
                else
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this product?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        inventory.RemoveProduct(selectedProductID);
                        dataGridViewProducts.DataSource = inventory.Products;
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a product to delete.");
            }
        }
        private void ModifyProduct(object sender, EventArgs e)
        {
            if (dataGridViewProducts.SelectedRows.Count > 0)
            {
                int selectedProductId = int.Parse(dataGridViewProducts.SelectedRows[0].Cells[0].Value.ToString());

                Product selectedProduct = inventory.LookupProduct(selectedProductId);

                if (selectedProduct != null)
                {
                    ModifyProduct modifyProductForm = new ModifyProduct(inventory, selectedProduct);
                    modifyProductForm.ShowDialog();
                    dataGridViewProducts.DataSource = inventory.Products;
                }
                else
                {
                    MessageBox.Show("Product not found.");
                }
            }
            else
            {
                MessageBox.Show("Please select a product to modify.");
            }
        }

    }

}
